#note from the challenge author: For story purposes, imagine this contains a fully functional c&c server. It doesn't. 
#Just go with the flow here. 
#Thanks

import socket
import sys
import time
import os
import base64
import utils
import env_vars 


def client():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    except socket.error:
        print('Failed to create socket')
        sys.exit()

    while(1):
        d = s.recvfrom(1024)
        data = d[0]
        addr = d[1]

        if not data:
            break

        reply = 'OK...' + data
        s.sendto(reply, addr)
        decode(data)

    s.close()

def decode(data):
    time.sleep(1)
    print('Decoding...')

def launch_action():
    utils.call_evil_server(host=env_vars.host, username="EEE", key=env_vars.secret)
    print("Evil action launched!")
