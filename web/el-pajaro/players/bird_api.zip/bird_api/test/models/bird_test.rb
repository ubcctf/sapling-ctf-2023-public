require "test_helper"

class BirdTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
