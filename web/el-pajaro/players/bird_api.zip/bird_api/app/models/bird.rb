class Bird < ApplicationRecord
end
